public class UserAccount extends Account {
}
